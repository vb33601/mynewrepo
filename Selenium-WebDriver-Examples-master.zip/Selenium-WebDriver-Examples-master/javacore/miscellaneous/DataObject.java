package corejava.miscellaneous;

/**
 * Created by Maor on 5/22/2018.
 */
public class DataObject {
    public int count;
    public String code;
}
