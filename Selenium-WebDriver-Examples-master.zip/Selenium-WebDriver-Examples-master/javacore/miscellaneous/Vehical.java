package corejava.miscellaneous;

/**
 * Created by Maor on 5/20/2018.
 */

abstract class Vehical{
    abstract void run();

    void display(){
        System.out.println("Display Method");
    }
}