package corejava.enumeration;

/**
 * Created by Maor on 5/22/2018.
 */
public class UserStatusTest {

    public static void main(String[] args) {

        //ACTIVE
        System.out.println(UserStatus.PENDING);
    }
}
