package corejava.basics;

/**
 * Created by Maor on 5/22/2018.
 */

// Simple print program - Print text and go to new line
public class Print1 {

    public static void main(String [] args){

        // println adds a new line
        System.out.println("Learning Java");
        System.out.println("Learning Java");
    }
}

