package corejava.basics;

/**
 * Created by Maor on 5/23/2018.
 */

public class Comments {

    public static void main(String[] args) {

        // Single line comment:
        System.out.println("Single line comment");

        /* Multi line comment"
           Comments in between
           the code gives more
           readability
		*/

        System.out.println("Multi line comment");

    }
}
