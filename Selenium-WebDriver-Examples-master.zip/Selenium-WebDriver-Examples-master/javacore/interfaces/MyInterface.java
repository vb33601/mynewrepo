package corejava.interfaces;

/**
 * Created by Maor on 6/3/2018.
 */

public interface MyInterface {

    // Compiler treats it as public abstract void myMethodOne();
    // Below method has no body
    public void myMethodOne();
}
