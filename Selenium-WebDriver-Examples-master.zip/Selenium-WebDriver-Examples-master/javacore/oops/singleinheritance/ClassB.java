package corejava.oops.singleinheritance;

/**
 * Created by Maor on 5/25/2018.
 */

public class ClassB extends ClassA {

    void methodOneClassB(){
        System.out.println("I am a Method One of ClassB");
    }
}
