package corejava.oops.polymorphism;

/**
 * Created by Maor on 5/25/2018.
 */

public class MethodOverridingParentClass {

    public void myMethod(){
        System.out.println("I am a method from the Parent Class");
    }
}
