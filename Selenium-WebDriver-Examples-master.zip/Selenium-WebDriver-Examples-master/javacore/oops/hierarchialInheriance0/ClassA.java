package corejava.oops.hierarchialInheriance0;

/**
 * Created by Maor on 5/25/2018.
 */

public class ClassA {

    void methodOneClassA(){
        System.out.println("I am a Method One of ClassA");
    }
}
