package corejava.arrays;

/**
 * Created by Maor on 5/26/2018.
 */

public class ArrayEnhancedForLoop {

    public static void main(String[] args) {

        int[] arr = {11,22,33,44,55};

        for(int a:arr){
            System.out.println(a);
        }
    }
}