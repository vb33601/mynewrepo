package corejava.arrays;

/**
 * Created by Maor on 6/4/2018.
 */

public class ArrayForLoop {

    public static void main(String[] args) {

        int[] arr = {11,22,33,44,55};

        for(int i=0; i<arr.length; i++){
            System.out.println(arr[i]);
        }

    }
}
