package corejava.exceptionhandling;

/**
 * Created by Maor on 5/26/2018.
 */

public class ArithmeticExceptionClass {

    public static void main(String [] args){
        int a = 100;
        int b = 0;
        System.out.println(a/b);
    }
}
