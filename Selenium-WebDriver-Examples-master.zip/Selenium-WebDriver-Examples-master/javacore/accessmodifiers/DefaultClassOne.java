package corejava.accessmodifiers;

/**
 * Created by Maor on 5/25/2018.
 */
public class DefaultClassOne {

    // Here I did'nt mention any modifier so it acts as a default modifier.
    protected int myMethod(int x){
        return x;
    }
}
