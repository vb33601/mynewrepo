package corejava.accessmodifiers;

/**
 * Created by Maor on 5/25/2018.
 */
public class PrivateClassOne {

    private int x = 100;
    int y = 200;


    private int myMethod(int a){
        return a;
    }

    int myMethodOne(int a){
        return a;
    }
}
