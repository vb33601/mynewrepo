package corejava.operators;

/**
 * Created by Maor on 5/23/2018.
 */
public class ArthimeticOperators {

    public static void main(String[] args) {

        int num1 = 100;
        int num2 = 50;

        System.out.println("Addition of two numbers is " + (num1 + num2));
        System.out.println("Subtraction of two numbers is " + (num1 - num2));
        System.out.println("Multiplication of two numbers is " + (num1 * num2));
        System.out.println("Division of two numbers is " + (num1 / num2));
        System.out.println("Modulus of two numbers is " + (num1 % num2));

    }
}
