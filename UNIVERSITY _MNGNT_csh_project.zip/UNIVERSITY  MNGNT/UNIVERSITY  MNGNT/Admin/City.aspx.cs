using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_City : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=HOME;initial catalog=UMS;integrated security=true;");
    }
    protected void btnSave_Click(object sender, EventArgs e)
    { }
    //{
    //    if (txtCityCode.Text != "")
    //    {
    //        if (txtCityName.Text != "")
    //        {

    //            if (txtRegionalCode.Text != "")
    //            {
    //                cmd = new SqlCommand("insert into tblCity (CityCode,CityName,RegionalCode) values ('" + txtCityCode.Text + "','" + txtCityName.Text + "','" + txtRegionalCode.Text + "')", con);
    //                con.Open();
    //                cmd.ExecuteNonQuery();
    //                lblMsg.Text = "Record Inserted";
    //                con.Close();
    //                txtCityName.Text = "";
    //                txtCityCode.Text = "";
    //                txtRegionalCode.Text = "";
    //                txtCityCode.Focus();
    //                GridView1.DataBind();
    //            }
    //            else
    //            {
    //                lblMsg.Text = "Enter RegionalCode";
    //            }



    //        }
    //        else
    //        {
    //            lblMsg.Text = "Write City Name";
    //        }
    //    }
    //    else
    //    {
    //        lblMsg.Text = "Write City Code";
    //    }

    //}
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //txtCityName.Text = "";
        //txtCityCode.Text = "";
        //txtCityCode.Focus();
        //lblMsg.Text = "";
    }
}
