using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_Regional : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=HOME;initial catalog=UMS;integrated security=true;");
        //lblMsg.Text = "";
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        //if (txtRegionalCode.Text!="")
        //{
        //    if (txtRegionalName.Text!="")
        //    {
        //        if (txtAddress.Text!="")
        //        {
        //            cmd = new SqlCommand("insert into tblRegional (RegionalCode,RegionalName,Address) values ('" + txtRegionalCode.Text + "','" + txtRegionalName.Text + "','" + txtAddress.Text + "')", con);
        //            con.Open();
        //            cmd.ExecuteNonQuery();
        //            lblMsg.Text = "Record Inserted";
        //            con.Close();
        //            txtRegionalCode.Text = "";
        //            txtRegionalName.Text = "";
        //            txtAddress.Text = "";
        //            txtRegionalCode.Focus();
        //            GridView1.DataBind();
        //        }
        //        else
        //        {
        //            lblMsg.Text = "Write Address";
        //        }
        //    }
        //    else
        //    {
        //        lblMsg.Text = "Write Regional Name";
        //    }
        //}
        //else
        //{
        //    lblMsg.Text = "Write Regional Code";
        //}
        
        
        
       
        
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //txtRegionalCode.Text = "";
        //txtRegionalName.Text = "";
        //txtAddress.Text = "";
        //txtRegionalCode.Focus();
        //lblMsg.Text = "";
    }
}
