using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BusinessLayer;

public partial class Admin_UserControls_City : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        txtCityCode.Focus();
        fillcity();
        fillregional();
    }

    private void fillcity()
    {
        City objCity = new City();
        DataTable dt = objCity.SelectCity();
        grdCity.DataSource = dt;
        grdCity.DataBind();
    }

    private void fillregional()
    {
        Regional objRegional = new Regional();
        DataTable dt = objRegional.SelectRegional();
        grdRegional.DataSource = dt;
        grdRegional.DataBind();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        City objCity = new City();
        objCity.CityCode = txtCityCode.Text;
        objCity.CityName = txtCityName.Text;
        objCity.RegionalCode = txtRegionalCode.Text;
        objCity.InsertCity();
        lblMsg.Text = "Data Inserted Successfully";
        EmptyTextboxes();
        fillcity();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        EmptyTextboxes();
    }

    private void EmptyTextboxes()
    {
        txtRegionalCode.Text = "";
        txtCityName.Text = "";
        txtCityCode.Text = "";
    }
}
