using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BusinessLayer;

public partial class Admin_UserControls_Course : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        fillcourse();
        fillcollege();
    }

    private void fillcollege()
    {
        College objCollege = new College();
        DataTable dt = objCollege.SelectCollege();
        grdCollege.DataSource = dt;
        grdCollege.DataBind();
    }

    private void fillcourse()
    {
        Course objCourse = new Course();
        DataTable dt = objCourse.SelectCourse();
        grdCourse.DataSource = dt;
        grdCourse.DataBind();

    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        Course objCourse = new Course();
        objCourse.CourseName = txtCourseName.Text;
        objCourse.Feestructure = txtFeestructure.Text;
        objCourse.CollegeCode = txtCourseCode.Text;
        objCourse.InsertCourse();
        lblMsg.Text = "Data Inserted Successfully";
        Emptytextboxes();
        fillcourse();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Emptytextboxes();
    }

    private void Emptytextboxes()
    {
        txtCourseCode.Text = "";
        txtCourseName.Text = "";
        txtFeestructure.Text = "";
    }
}
