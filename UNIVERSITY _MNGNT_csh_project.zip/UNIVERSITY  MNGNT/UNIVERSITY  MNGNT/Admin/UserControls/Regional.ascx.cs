using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BusinessLayer;

public partial class Admin_UserControls_Regional : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        txtRegionalCode.Focus();
        fillregional();
    }

    private void fillregional()
    {
        Regional objRegional = new Regional();
        DataTable dt = objRegional.SelectRegional();
        grdRegional.DataSource = dt;
        grdRegional.DataBind();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        Regional objRegional = new Regional();
        objRegional.RegionalCode = txtRegionalCode.Text;
        objRegional.RegionalName = txtRegionalName.Text;
        objRegional.Address = txtAddress.Text;
        objRegional.InsertRegional();
        lblMsg.Text = "Data Inserted Successfully";
        EmptyTextBoxes();
        fillregional();

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        EmptyTextBoxes();
    }

    private void EmptyTextBoxes()
    {
        txtAddress.Text = "";
        txtRegionalCode.Text = "";
        txtRegionalName.Text = "";
    }
}
