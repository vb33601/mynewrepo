using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BusinessLayer;

public partial class Admin_UserControls_Result : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        formca();
        forbca();
        
    }

    private void formca()
    {
        Mca objMca = new Mca();
        DataTable dt = objMca.SelectMcaMarksforadmin();
        grdMca.DataSource = dt;
        grdMca.DataBind();
    }

    private void forbca()
    {
        Bca objBca = new Bca();
        DataTable dt = objBca.SelectBcaMarksforadmin();
        grdBca.DataSource = dt;
        grdBca.DataBind();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        Bca objBca = new Bca();
        objBca.EnrolmentNo = txtEnrolmentno.Text;
        objBca.Name = txtName.Text;
        objBca.CS61 = txt61.Text;
        objBca.CS62 = txt62.Text;
        objBca.CS63 = txt63.Text;
        objBca.CS64 = txt64.Text;
        objBca.InsertBcaMarks();
        lblMsg.Text = "Record Inserted Successfully";
        forbca();
        emptybca();
    }

    private void emptybca()
    {
        txtEnrolmentno.Text = "";
        txtName.Text = "";
        txt61.Text = "";
        txt62.Text = "";
        txt63.Text="";
        txt64.Text="";
    }
    protected void btnMsave_Click(object sender, EventArgs e)
    {
        Mca objMca = new Mca();
        objMca.EnrolmentNo = txtMenno.Text;
        objMca.Name = txtMname.Text;
        objMca.CS01 = txt01.Text;
        objMca.CS02 = txt02.Text;
        objMca.CS03 = txt03.Text;
        objMca.CS04 = txt04.Text;
        objMca.InsertMcaMarks();
        lblMMsg.Text = "Record Inserted Successfully";
        formca();
        emptymca();
    }

    private void emptymca()
    {
        txtMenno.Text = "";
        txtMname.Text = "";
        txt01.Text = "";
        txt02.Text="";
        txt03.Text="";
        txt04.Text="";
    }
}
