using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BusinessLayer;

public partial class Admin_UserControls_College : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        txtCollegeCode.Focus();
        fillcollege();
        fillcity();
    }

    private void fillcollege()
    {
        College objCollege = new College();
        DataTable dt = objCollege.SelectCollege();
        grdCollege.DataSource = dt;
        grdCollege.DataBind();
    }

    private void fillcity()
    {
        City objCity = new City();
        DataTable dt = objCity.SelectCity();
        grdCity.DataSource = dt;
        grdCity.DataBind();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        College objCollege = new College();
        objCollege.CollegeCode = txtCollegeCode.Text;
        objCollege.StudyCenterCode = txtStudyCenterCode.Text;
        objCollege.StudyCenterName = txtStudyCenterName.Text;
        objCollege.CityCode = txtCityCode.Text;
        objCollege.CollegeAddress = txtCollegeAddress.Text;
        objCollege.InsertCollege();
        lblMsg.Text = "Data Inserted Successfully";
        emptytextboxes();
        fillcollege();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        emptytextboxes();


    }

    private void emptytextboxes()
    {
        txtCityCode.Text = "";
        txtCollegeAddress.Text = "";
        txtCollegeCode.Text = "";
        txtStudyCenterCode.Text = "";
        txtStudyCenterName.Text = "";
    }
}
