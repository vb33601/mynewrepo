using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_College : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=HOME;initial catalog=UMS;integrated security=true;");
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        //if (txtCollegeCode.Text != "")
        //{
        //    if (txtStudyCenterCode.Text != "")
        //    {
        //        if (txtCityCode.Text != "")
        //        {
        //            if (txtStudyCenterName.Text != "")
        //            {
        //                if (txtCollegeAddress.Text != "")
        //                {
        //                    cmd = new SqlCommand("insert into tblCollege (CollegeCode,StudyCenterCode,CityCode,StudyCenterName,CollegeAddress) values ('" + txtCollegeCode.Text + "','" + txtStudyCenterCode.Text + "','" + txtCityCode.Text + "','" + txtStudyCenterName.Text + "','" + txtCollegeAddress.Text + "')", con);
        //                    con.Open();
        //                    cmd.ExecuteNonQuery();
        //                    lblMsg.Text = "Record Inserted";
        //                    con.Close();
        //                    txtCityCode.Text = "";
        //                    txtCollegeAddress.Text = "";
        //                    txtCollegeCode.Text = "";
        //                    txtStudyCenterCode.Text = "";
        //                    txtStudyCenterName.Text = "";
        //                    txtCollegeCode.Focus();
        //                    GridView1.DataBind();
        //                }
        //                else
        //                {
        //                    lblMsg.Text = "Write College Address";
        //                }
        //            }
        //            else
        //            {
        //                lblMsg.Text = "Write Study center Name";
        //            }
        //        }
        //        else
        //        {
        //            lblMsg.Text = "Write City Code";
        //        }
        //    }
        //    else
        //    {
        //        lblMsg.Text = "Write Study Center Code";
        //    }
        //}
        //else
        //{
        //    lblMsg.Text = "Write College Code";
        //}       
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //txtCityCode.Text = "";
        //txtCollegeAddress.Text = "";
        //txtCollegeCode.Text = "";
        //txtStudyCenterCode.Text = "";
        //txtStudyCenterName.Text = "";
        //txtCollegeCode.Focus();
        //lblMsg.Text = "";
    }
}
