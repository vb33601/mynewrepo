using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_Course : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=HOME;initial catalog=UMS;integrated security=true;");
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
    //    if (txtCourseCode.Text != "")
    //    {
    //        if (txtCourseName.Text != "")
    //        {
    //            if (txtFeestructure.Text != "")
    //            {
    //                cmd = new SqlCommand("insert into tblCourse (CollegeCode,CourseName,Feestructure) values ('" + txtCourseCode.Text + "','" + txtCourseName.Text + "','" + txtFeestructure.Text + "')", con);
    //                con.Open();
    //                cmd.ExecuteNonQuery();
    //                lblMsg.Text = "Record Inserted";
    //                con.Close();
    //                txtCourseCode.Text = "";
    //                txtCourseName.Text = "";
    //                txtFeestructure.Text = "";
    //                txtCourseCode.Focus();
    //                GridView1.DataBind();
    //            }
    //            else
    //            {
    //                lblMsg.Text = "Write Fee structure!";
    //            }
    //        }
    //        else
    //        {
    //            lblMsg.Text = "Write Course Name";
    //        }
    //    }
    //    else
    //    {
    //        lblMsg.Text = "Write Course Code";
    //    }

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //txtCourseCode.Text = "";
        //txtCourseName.Text = "";
        //txtFeestructure.Text = "";
        //txtCourseCode.Focus();
        //lblMsg.Text = "";
    }
}
