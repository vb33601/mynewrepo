using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_Result : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=HOME;Initial Catalog=UMS;Integrated Security=true;");

    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        //cmd = new SqlCommand("insert into tblBca (EnrolmentNo,Name,CS61,CS62,CS63,CS64) values ('" + txtEnrolmentno.Text + "','" + txtName.Text + "','" + txt61.Text + "','" + txt62.Text + "','" + txt63.Text + "','" + txt64.Text + "')", con);
        //con.Open();
        //if (cmd.ExecuteNonQuery()==1)
        //{
        //    lblMsg.Text = "Record Inserted";
        //}
        //else
        //{
        //    lblMsg.Text = "Record Not Inserted";
        //}
        //con.Close();
        //txtEnrolmentno.Text = "";
        //txtName.Text = "";
        //txt61.Text = "";
        //txt62.Text = "";
        //txt63.Text = "";
        //txt64.Text = "";
        //txtEnrolmentno.Focus();
        //GridView1.DataBind();
    }
    protected void btnMsave_Click(object sender, EventArgs e)
    {
        //cmd = new SqlCommand("insert into tblMca (EnrolmentNo,Name,CS01,CS02,CS03,CS04) values ('" + txtMenno.Text + "','" + txtMname.Text + "','" + txt01.Text + "','" + txt02.Text + "','" + txt03.Text + "','" + txt04.Text + "')", con);
        //con.Open();
        //if (cmd.ExecuteNonQuery() == 1)
        //{
        //    lblMMsg.Text = "Record Inserted";
        //}
        //else
        //{
        //    lblMMsg.Text = "Record Not Inserted";
        //}
        //con.Close();
        //txtMenno.Text = "";
        //txtMname.Text = "";
        //txt01.Text = "";
        //txt02.Text = "";
        //txt03.Text = "";
        //txt04.Text = "";
        //txtMenno.Focus();
        //GridView2.DataBind();
    }
    protected void Result1_Load(object sender, EventArgs e)
    {

    }
}
