using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BusinessLayer;

public partial class WebControls_ReRegistrationForm : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        txtName.Focus();
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        ReAdmission objReAdmission = new ReAdmission();
        objReAdmission.Name = txtName.Text;
        objReAdmission.Address = txtAddress.Text;
        objReAdmission.ProgrammeCode = txtProgrammeCode.Text;
        objReAdmission.EnrolmentNo = txtEnrolmentNo.Text;
        objReAdmission.RegionalCode = txtRegionalCode.Text;
        objReAdmission.StudyCenterCode = txtStudyCenterCode.Text;
        objReAdmission.DetailsOfCourse = txtDetailsOfCourse.Text;
        objReAdmission.Year = txtYear.Text;
        objReAdmission.InsertReAdmission();
        lblMsg.Text = "Data Inserted Successfully";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
}
