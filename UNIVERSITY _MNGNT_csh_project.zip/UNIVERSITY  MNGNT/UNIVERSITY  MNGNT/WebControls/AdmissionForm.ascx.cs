using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BusinessLayer;

public partial class WebControls_AdmissionForm : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        txtName.Focus();
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        Admission objAdmission = new Admission();
        objAdmission.Name = txtName.Text;
        objAdmission.Address = txtAddress.Text;
        objAdmission.CourseName = txtCourseName.Text;
        objAdmission.RegionalCode = txtRegionalCode.Text;
        objAdmission.StudyCenterCode = txtStudyCenterCode.Text;
        objAdmission.InsertAdmission();
        lblMsg.Text = "Data Inserted Successfully";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
}
