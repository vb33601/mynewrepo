using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using BusinessLayer;

public partial class WebControls_Result : System.Web.UI.UserControl
{
    SqlCommand cmd;
    SqlConnection con;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=Akash;Initial Catalog=UMS;Integrated security=true;");
    }
    protected void btnGetResult_Click(object sender, EventArgs e)
    {
        if (txtEnrolmentno.Text != "")
        {
            if (cmbCourse.SelectedValue == "I.T.")
            {

                Forbca();
                
            }
            else
            {
                Formca();
                
            }
        }
        else
        {
            lblMsg.Text = "Please Enter Enrolment No";
        }

    }

    private void Formca()
    {
        Mca objMca = new Mca();
        objMca.EnrolmentNo = txtEnrolmentno.Text;
        DataTable dt = objMca.SelectMcaMarks();
        grdResult.DataSource = dt;
        grdResult.DataBind();

        //cmd = new SqlCommand("select * from tblMca where EnrolmentNo ='" + txtEnrolmentno.Text + "'", con);
        //SqlDataAdapter adpt = new SqlDataAdapter(cmd);
        //DataSet ds = new DataSet();
        //adpt.Fill(ds, "tblMca");
        //grdResult.DataSource = ds;
        //grdResult.DataMember = "tblMca";
        //grdResult.DataBind();
    }

    private void Forbca()
    {
        Bca objBca = new Bca();
        objBca.EnrolmentNo = txtEnrolmentno.Text;
        DataTable dt = objBca.SelectBcaMarks();
        grdResult.DataSource = dt;
        grdResult.DataBind();

        //cmd = new SqlCommand("select * from tblBca where EnrolmentNo ='" + txtEnrolmentno.Text + "'", con);
        //SqlDataAdapter adpt = new SqlDataAdapter(cmd);
        //DataSet ds = new DataSet();
        //adpt.Fill(ds, "tblBca");
        //grdResult.DataSource = ds;
        //grdResult.DataMember = "tblBca";
        //grdResult.DataBind();
    }
}
