using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using BusinessLayer;

public partial class WebControls_SearchRegional : System.Web.UI.UserControl
{
    SqlConnection con;
    SqlCommand cmd;

    DataSet ds = new DataSet();
    SqlDataAdapter adpt = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\UMS.mdf;Integrated Security=True;User Instance=True");
        if (!IsPostBack)
        {
            FillDataofRegional();

        }
    }
    protected void cmbRegional_SelectedIndexChanged(object sender, EventArgs e)
    {
        cmd = new SqlCommand("select r.RegionalCode,r.RegionalName,r.Address,c.CityCode,c.CityName from tblRegional r, tblCity c where r.RegionalCode = c.RegionalCode and c.RegionalCode = '" + cmbRegional.SelectedItem.Value.ToString() + "'", con);
        adpt = new SqlDataAdapter(cmd);
        adpt.Fill(ds);
        

        grdRegional.DataSource = ds.Tables[0];
        grdRegional.DataBind();
    }
    private void FillDataofRegional()
    {
        Regional objRegional = new Regional();
        DataTable dt = objRegional.SelectRegional();
        foreach (DataRow dr in dt.Rows)
        {
            //cmbRegional.Items.Add(dr[1].ToString());
            cmbRegional.Items.Add(new ListItem(dr[1].ToString(), dr[0].ToString()));
        }
    }
}
