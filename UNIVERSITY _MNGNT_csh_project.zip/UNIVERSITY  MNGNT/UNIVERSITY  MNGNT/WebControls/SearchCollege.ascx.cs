using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using BusinessLayer;

public partial class WebControls_SearchCollege : System.Web.UI.UserControl
{
    SqlConnection con;
    SqlCommand cmd;

    DataSet ds = new DataSet();
    SqlDataAdapter adpt = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=Akash;initial catalog=UMS;integrated security=true;");
        if (!IsPostBack)
        {
            FillDataofCollege();
        }
    }
    protected void cmbCollege_SelectedIndexChanged(object sender, EventArgs e)
    {
        cmd = new SqlCommand("select s.CollegeCode,s.StudyCenterName,s.CollegeAddress,c.CourseName,c.Feestructure from tblCourse c,tblCollege s where c.CollegeCode = s.CollegeCode and c.CollegeCode ='" + cmbCollege.SelectedItem.Value.ToString() + "'", con);
        adpt = new SqlDataAdapter(cmd);
        adpt.Fill(ds);
        grdCollege.DataSource = ds.Tables[0];
        grdCollege.DataBind();
    }
    private void FillDataofCollege()
    {
        //cmd = new SqlCommand("select * from tblCollege", con);
        //adpt = new SqlDataAdapter(cmd);
        College objCollege = new College();

        DataTable dt = objCollege.SelectCollege();
        
        foreach (DataRow dr in dt.Rows)
        {
            cmbCollege.Items.Add(new ListItem(dr[3].ToString(), dr[0].ToString()));
        }
    }
}
