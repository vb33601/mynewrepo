using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using BusinessLayer;

public partial class WebControls_SearchCourse : System.Web.UI.UserControl
{
    SqlConnection con;
    SqlCommand cmd;

    DataSet ds = new DataSet();
    SqlDataAdapter adpt = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=Akash;initial catalog=UMS;integrated security=true;");
        if (!IsPostBack)
        {
            FillDataofCourse();

        }

    }
    private void FillDataofCourse()
    {
        //cmd = new SqlCommand("select * from tblCourse", con);
        //adpt = new SqlDataAdapter(cmd);
        Course objCourse = new Course();
        DataTable dt = objCourse.SelectCourse();
        //adpt.Fill(ds);
        grdCourse.DataSource = dt;
        grdCourse.DataBind();
    }
}
