using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BusinessLayer;

public partial class WebControls_InstRegional : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Regional objRegional = new Regional();
        DataTable dt = objRegional.SelectRegional();
        grdRegional.DataSource = dt;
        grdRegional.DataBind();
    }
}
