using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using BusinessLayer;

public partial class WebControls_SearchCity : System.Web.UI.UserControl
{
    SqlConnection con;
    SqlCommand cmd;

    DataSet ds = new DataSet();
    SqlDataAdapter adpt = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ToString());
        if (!IsPostBack)
        {
            FillDataofCity();
        }
    }
    protected void cmbCity_SelectedIndexChanged(object sender, EventArgs e)
    {
        cmd = new SqlCommand("select c.CityCode,c.CityName,s.CollegeCode,s.StudyCenterName,s.CollegeAddress from tblCollege s, tblCity c where c.CityCode = s.CityCode and s.CityCode ='" + cmbCity.SelectedItem.Value.ToString() + "'", con);
        adpt = new SqlDataAdapter(cmd);
        adpt.Fill(ds);
        grdCity.DataSource = ds.Tables[0];
        grdCity.DataBind();
    }
    private void FillDataofCity()
    {
       
        City objCity = new City();

        DataTable dt = objCity.SelectCity();
        //adpt.Fill(ds);
        foreach (DataRow dr in dt.Rows)
        {
            cmbCity.Items.Add(new ListItem(dr[1].ToString(), dr[0].ToString()));
        }
    }
}
