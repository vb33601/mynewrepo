using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class WebControls_AdFormForPrint : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        dvAdForm1.Visible = true;
        dvAdForm2.Visible = false;
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        dvAdForm1.Visible = false;
        dvAdForm2.Visible = true;
    }
}
