### Index

* [0 - MOOC](#0---mooc)
* [Flutter](#flutter)
* [Linux](#linux)


### 0 - MOOC

* [freeCodeCamp](https://chinese.freecodecamp.org)


### Flutter

* [Flutter 仿微信朋友圈](https://www.youtube.com/playlist?v=7lZRWWELIaA&list=PL274L1n86T80VQcJb76zcXcPpF-S-fFV-) - ducafecat


### Linux

* [Linux 核心設計](https://youtube.com/playlist?list=PL6S9AqLQkFpongEA75M15_BlQBC9rTdd8) - jserv
