### Index

* [Android](#android)
* [HTML and CSS](#html-and-css)
* [JavaScript](#javascript)
* [PHP](#php)
* [Python](#python)


### Деңгейлер

BEGINNER - бастаушы. Түбір базалық кодты үйрену.
INTERMEDIATE - жалғастырушы. Мүмкіндіктердің арттырылуы.
ADVANCED - дамытушы. Детальді кодты үйрену.


### Android

* [Android](https://bilgen.academy/course/view.php?id=512) (BEGINNER)


### HTML and CSS

* [HTML/CSS. базалық веб-дизайн құрудағы кодтау.](https://bilgen.academy/course/view.php?id=510) (BEGINNER)


### JavaScript

* [Javascript. Java курсының негізі](https://bilgen.academy/course/view.php?id=506) (BEGINNER)


### PHP

* [PHP. Веб-дизайнның динамикалық базасының құрылуы.](https://bilgen.academy/course/view.php?id=508) (BEGINNER)


### Python

* [Python тiлiнде бағдарламалау негiздерi.](https://openu.kz/kz/courses/python-tilinde-badarlamalau-negizderi) - Жасдәурен Дүйсебеков (Қазақстанның ашық университеті) *(тіркелуді талап етпейді)*
