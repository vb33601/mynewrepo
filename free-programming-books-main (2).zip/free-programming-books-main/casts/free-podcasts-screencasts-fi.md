# Podcastit

* [Kahvit näppikselle](https://www.aalto.fi/fi/podcastit/kahvit-nappikselle) - Aalto-yliopisto (podcast)
* [Koodarikuiskaajan podcast](https://koodarikuiskaaja.simplecast.com) - Elisa Heikura (podcast)
* [Koodia pinnan alla](https://koodiapinnanalla.fi) - Markus Hjort ja Yrjö Kari-Koskinen (podcast)
* [Koodikahvit](https://audioboom.com/channels/5016335) - Anniina ja Pauliina (podcast)
* [Koodikrapula](https://koodikrapula.fi) - Hannes Kinnunen ja Matias Kinnunen (podcast)
* [Prochat - Identio](https://podtail.com/fi/podcast/prochat) - Identio (podcast)
* [Webbidevaus](https://webbidevaus.fi) - Antti Mattila, Tommi Pääkkö ja Riku Rouvila (podcast)
