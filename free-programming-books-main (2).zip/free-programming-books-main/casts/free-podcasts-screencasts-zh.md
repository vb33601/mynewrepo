### Index

* [JavaScript](#javascript)
* [Python](#python)
* [Swift](#swift)


### JavaScript

* [Async Talk](https://asynctalk.com) - AnnatarHe, Sleaf, TinkoQWQ (podcast)
* [Web Worker 播客](https://www.webworker.tech) - 辛宝Otto, 刘威Franky, 小白菜Cabbage (podcast)


### Python

* [捕蛇者说](https://pythonhunter.org) - laike9m, Manjusaka, Ada Wen, laixintao, 小白 (podcast)


### Swift

* [weak self podcast](https://weakself.dev) - 一三, 波肥, 喬喬 (podcast)
