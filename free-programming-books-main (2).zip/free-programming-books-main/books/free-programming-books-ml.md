### Index

* [Computer Science](#computer-science)


### Computer Science

* [XI_Computer_Science_Part_I](https://samagra.kite.kerala.gov.in/files/samagra-resource/uploads/tbookscmq/Class_XI/CompSciencepart1/XI_Computer_Science_Part_1.pdf) - SCERT (PDF)
* [XI_Computer_Science_Part_II](https://samagra.kite.kerala.gov.in/files/samagra-resource/uploads/tbookscmq/Class_XI/CompSciencepart1/XI_Computer_Science_Part_II.pdf) - SCERT (PDF)
* [XII_Computer_Science_Part_I](https://samagra.kite.kerala.gov.in/files/samagra-resource/uploads/tbookscmq/Class_XII/MAL_MED/Computer%20Science%20Part%201%20.pdf) - SCERT (PDF)
* [XII_Computer_Science_Part_II](https://samagra.kite.kerala.gov.in/files/samagra-resource/uploads/tbookscmq/Class_XII/MAL_MED/Computer%20Science%20Part%202.pdf) - SCERT (PDF)



