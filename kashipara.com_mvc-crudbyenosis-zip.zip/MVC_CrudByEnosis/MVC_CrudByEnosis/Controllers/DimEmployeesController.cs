﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MVC_CrudByEnosis;

namespace MVC_CrudByEnosis.Controllers
{
    public class DimEmployeesController : Controller
    {
        private AdventureWorksEntities db = new AdventureWorksEntities();

        // GET: DimEmployees
        public ActionResult Index()
        {
            var dimEmployees = db.DimEmployees.Include(d => d.DimEmployee2);
            return View(dimEmployees.ToList());
        }

        // GET: DimEmployees/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DimEmployee dimEmployee = db.DimEmployees.Find(id);
            if (dimEmployee == null)
            {
                return HttpNotFound();
            }
            return View(dimEmployee);
        }

        // GET: DimEmployees/Create
        public ActionResult Create()
        {
            ViewBag.ParentEmployeeKey = new SelectList(db.DimEmployees, "EmployeeKey", "EmployeeNationalIDAlternateKey");
            return View();
        }

        // POST: DimEmployees/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "EmployeeKey,ParentEmployeeKey,EmployeeNationalIDAlternateKey,ParentEmployeeNationalIDAlternateKey,SalesTerritoryKey,FirstName,LastName,MiddleName,NameStyle,Title,HireDate,BirthDate,LoginID,EmailAddress,Phone,MaritalStatus,EmergencyContactName,EmergencyContactPhone,SalariedFlag,Gender,PayFrequency,BaseRate,VacationHours,SickLeaveHours,CurrentFlag,SalesPersonFlag,DepartmentName,StartDate,EndDate,Status")] DimEmployee dimEmployee)
        {
            if (ModelState.IsValid)
            {
                db.DimEmployees.Add(dimEmployee);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.ParentEmployeeKey = new SelectList(db.DimEmployees, "EmployeeKey", "EmployeeNationalIDAlternateKey", dimEmployee.ParentEmployeeKey);
            return View(dimEmployee);
        }

        // GET: DimEmployees/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DimEmployee dimEmployee = db.DimEmployees.Find(id);
            if (dimEmployee == null)
            {
                return HttpNotFound();
            }
            ViewBag.ParentEmployeeKey = new SelectList(db.DimEmployees, "EmployeeKey", "EmployeeNationalIDAlternateKey", dimEmployee.ParentEmployeeKey);
            return View(dimEmployee);
        }

        // POST: DimEmployees/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "EmployeeKey,ParentEmployeeKey,EmployeeNationalIDAlternateKey,ParentEmployeeNationalIDAlternateKey,SalesTerritoryKey,FirstName,LastName,MiddleName,NameStyle,Title,HireDate,BirthDate,LoginID,EmailAddress,Phone,MaritalStatus,EmergencyContactName,EmergencyContactPhone,SalariedFlag,Gender,PayFrequency,BaseRate,VacationHours,SickLeaveHours,CurrentFlag,SalesPersonFlag,DepartmentName,StartDate,EndDate,Status")] DimEmployee dimEmployee)
        {
            if (ModelState.IsValid)
            {
                db.Entry(dimEmployee).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.ParentEmployeeKey = new SelectList(db.DimEmployees, "EmployeeKey", "EmployeeNationalIDAlternateKey", dimEmployee.ParentEmployeeKey);
            return View(dimEmployee);
        }

        // GET: DimEmployees/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DimEmployee dimEmployee = db.DimEmployees.Find(id);
            if (dimEmployee == null)
            {
                return HttpNotFound();
            }
            return View(dimEmployee);
        }

        // POST: DimEmployees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            DimEmployee dimEmployee = db.DimEmployees.Find(id);
            db.DimEmployees.Remove(dimEmployee);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
