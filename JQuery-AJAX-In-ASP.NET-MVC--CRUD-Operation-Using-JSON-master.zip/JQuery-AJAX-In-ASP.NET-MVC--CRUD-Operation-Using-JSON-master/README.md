# JQuery-AJAX-In-ASP.NET-MVC--CRUD-Operation-Using-JSON
JQuery, AJAX In ASP.NET MVC- CRUD Operation Using JSON

We are going to Cover following Sections in this Project::

1) Create a Project
2) Create a Database
3) Add Entity Model for Database
4) Add MVC COntroller
5) Implement Bootstrap Tab Control
6) View All (Implement the Operations)
7) INSERT Operation
8) Add Sceript File for jQuery AJAX CRUD Operation
9) Client Side Validation
10) Download & Install NotifyJS
http://notifyjs.com/
And Download notify.min.js
11) UPDATE Operation
12) DELETE Operation
13) Implement jQuery Datatable
https://datatables.net/examples/basic_init/zero_configuration.html
a) Copy CSS Refrence, Add to Index.cshtml
b) Copy the Javascript, Add to Index.cshtml
14) Add Loading Spinner or Loading Image Into ASP.NET MVC AJAX jQuery CRUD Operation


